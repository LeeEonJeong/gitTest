<?php
//db에서 volume 가져오기
/*
 * 유저에 따른 사용가능한 볼륨 리스트 가져오기
 * 볼륨별 정보 가져오기(서버와 연결된)
 * 
 * */
class VolumesModel extends CI_Model{
	
}