<div class="span10">
	<!-- 네트워크정보 -->
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12" id='networkinfo'>
			<h5>선택된 네트워크 : <span id="selectipaddress"></span></h5>
			
			<div id="publicipinfo">
				<table class="table table-condensed" id="publicipinfo_table">
				 	<tr>
				 		<th class="subtitle">공인IP</th>
				 		<th id="ipaddress"></th>
				 		<th class="subtitle">IP ID</th>
				 		<th id="id"></th>
				 	</tr>
				 	<tr>
				 		<th class="subtitle">취득 날짜</th>
				 		<th id="allocated"></th>
				 		<th class="subtitle">주소 상태</th>
				 		<th id="state"></th>
				 	</tr>
				 	 
				</table>
			</div>
			<div id="firwallinfo">
				 <table id="firwallinfo_table" class="table table-condensed">
				 	<tr style='background-color:#fefefe'>
				 		<th class="subtitle">cirlist</th>
				 		<th class="subtitle">Protocol</th>
				 		<th class="subtitle">Start Port</th>
				 		<th class="subtitle">End Port</th>
				 		<th  class="subtitle">삭제 및 수정</th>
				 	</tr>
				 </table>
			</div>
			<div id="portforwardinginfo">
				
			</div>
		</div>
	</div>