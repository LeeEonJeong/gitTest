
<?php ?>
</div>
</div>

<!-- 나중에 if문으로 수정 해야함 .. 서버클라우드리스트같은경우 -->

</div>
</div>
<!-- 마지막 div2개는 head의 container-fluid와 row-fluid -->


<script src="http://code.jquery.com/jquery.js"></script>
<script src="/project1/static/lib/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>