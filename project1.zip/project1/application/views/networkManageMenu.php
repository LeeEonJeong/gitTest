<div class="span2"> 
	 <ul class="nav nav-list" id="networkMangeMenu">
		  <li class="nav-header">상세정보</li>
		  <li id="firwallMenu"><a href="#">방화벽</a></li>
		  <li><a href="#">포트포워딩</a></li>	 
	</ul> 
 </div>
