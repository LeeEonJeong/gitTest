<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	class OrderCloud extends MY_Controller{
		function __construct()
		{
			parent::__construct();
			$this->load->model('orderCloudModel');
		}
	 
		
		function index(){
			$this->_head();
			$returnURI = '/cloudlist'; // 일단임의로 나중에 returnURI 다시 처리하자
			$this->_require_login($returnURI);
			 
			$this->load->view ('orderCloud');
			$this->_footer ();
		} 
		
		function getlistAvailableProductTypes(){
			echo 'test';
			$this->orderCloudModel->getlistAvailableProductTypes();
		}
		
		function getPackages(){
			$packages =  $this->orderCloudModel->getPackages();
			
			echo json_encode($packages);
		}
		
		function getProductsByPackage($package){
			if(!$package){
				$package = $_POST('$package');
			}
			$package = 'Standard'; //임의로
			$proudcts = $this->orderCloudModel->getProductsByPackage($package);
			
			echo json_encode($package);
		}
		
		
	}