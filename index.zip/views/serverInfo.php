<div class="span10">
	<!-- 서버정보 -->
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<table class="table table-condensed" >
				 	<tr>
				 		<th class="subtitle">인스턴스명</th>
				 		<th><?= $server[0]['displayname']?></th>
				 		<th class="subtitle">호스트명</th>
				 		<th><?= $server[0]['name']?></th>
				 	</tr>
				 	<tr>
				 		<th class="subtitle">서버 ID</th>
				 		<th colspan="3"><?= $server[0]['id']?></th>
				 	</tr>
				 	
				 	<tr>
				 		<th class="subtitle">내부주소</th>
				 		<th><?= $server[0]['nic']['ipaddress']?></th>
				 		<th class="subtitle">외부주소</th>
				 		<th><?= $server[0]['nic']['netmask']?></th>
				 	</tr>
				 	
				 	<tr>
				 		<th class="subtitle">운영체제</th>
				 		<th><?= $server[0]['templatename']?></th>
				 		<th class="subtitle">데이터센터</th>
				 		<th><?= $server[0]['zonename']?></th>
				 	</tr>
				 	
				 	<tr>
				 		<th class="subtitle">CPU/메모리</th>
				 		<th><?= $server[0]['serviceofferingname']?></th>
				 		<th class="subtitle">생성시간</th>
				 		<th><?= $server[0]['created']?></th>
				 	</tr>
				 	<tr>
				 		<th class="subtitle">상태</th>
				 		<th colspan="3"><?= $server[0]['state']?></th>
				 	</tr>
				 					 	 
				</table>
		</div>
	</div>