  <script>
$(
		//존위치에 따라 패키지 선택지 가져오기
		function(){ 
			$("#zonename").change( 
				function(){ 
				    zoneid = $('#zonename option:selected').val();
				    $.ajax({
						type : "POST",
						url: 'http://localhost/project1/index.php/orderCloud/getPackages',
						data : {'zoneid' : zoneid},
						datatype : 'json',
						success : function(data)
						{ 
							var obj = jQuery.parseJSON(data);
//								alert(obj[1]);
//								alert(obj.length);
							$('#package').empty(); //내용비움
							for(var i=0; i<obj.length; i++){ 
								$('#package ').append(
									$('<input/>').attr({
												type:'button',
												id:obj[i],
												value:obj[i],
												class:'btn'											 
									})
								);
								$('#'+obj[i]).click(
									function(){
										$.ajax({
											type : "POST",
											url: 'http://localhost/project1/index.php/orderCloud/getProductsByPackage',
											data : {'package' : obj[i]},
											datatype : 'json',
											success : function(data)
											{ 
												var obj2 = jQuery.parseJSON(data); 
												$('#package').empty(); //내용비움
												for(var i=0; i<obj2.length; i++){ 
													$('#product #products').append(
														$('<li></li>').html(obj2[i])	 
													);
												}
												
											},
											error : function( ){  
												alert('실행실패'); 
											}
									});
														
									}
								);
							}
							
						},
						error : function( ){  
							alert('실행실패'); 
						}
					});
						
				})

		//패키지 선택에 따라 운영체제 사양 가져오기		
			  
});  
</script>
			<h3>서버생성</h3>
			<hr>
			<div class="span3" style="border:1px solid black">
			   	<table>
			   		<tr>
			   			<td>서버명</td>
			   			<td colspan="2"><input type="text"/></td>
			   			<td></td>
			   		</tr>
			   		<tr>
			   			<td>호스트명</td>
			   			<td colspan="2"><input type="text"/></td>
			   			<td></td>
			   		</tr>
			   		<tr>
			   			<td>위치</td>
			   			<td>
			   				<select id='zonename'>
								<option selected value="eceb5d65-6571-4696-875f-5a17949f3317">KOR-Central A</option>
								<option value="9845bd17-d438-4bde-816d-1b12f37d5080">KOR-Central B</option>
								<option value="dfd6f03d-dae5-458e-a2ea-cb6a55d0d994">KOR-HA</option>
								<option value="95e2f517-d64a-4866-8585-5177c256f7c7">KOR-Seoul M</option>
								<option value="3e8ce14a-09f1-416c-83b3-df95af9d6308">JPN</option>
								<option value="b7eb18c8-876d-4dc6-9215-3bd455bb05be">US-West</option>
							</select>
			   			</td>
			   			<td></td>
			   		</tr>
			   	</table>  
			</div>
			<div class="span4" style="border:1px solid black" id="selectOS">
				운영체제 선택하기
				<div id="product"></div>
				<ul id="prudcts"></ul>
				<br>
				패키지 선택
				<div id="package"></div>
				<br>
			</div>
			<div class="span4"style="border:1px solid black" id="selectServer">
				서버사양 선택하기
				<div id="server"></div>
			</div>
		</div>
	</div>
</div>