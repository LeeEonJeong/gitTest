<span style="display:none" id="where" >cloudlist</span>
 
<!-- <form class="form-search"> -->
<!--   <input type="text" class="input-medium search-query" placeholder="검색할 서버명"> -->
<!--   <button type="submit"><i class="icon-search"></i></button> -->
<!-- </form> -->
<script>
 
</script>
<!-- 서버검색하기 -->
	<div class="container-fluid">
		<div class="row-fluid" >
			<div class="span7"  >
				<h5>서버검색하기</h5>
				<form>
					<div id="custom-search-input">
						<select>
							<option>전체</option>
							<option>KOR-Central A</option>
							<option>KOR-Central B</option>
							<option>KOR-HA</option>
							<option>KOR-Seoul M</option>
							<option>JPN</option>
						</select> <input type="text" class="input-medium search-query"
							placeholder="검색할 서버명을  입력해 주세요." />
						<span class="input-group-btn">
							<button type="submit">
								<i class="icon-search fa-10x"></i> 검색
							</button>
						</span> 
					</div> 
				</form>
			</div>
			<div class="span5" >
			<div class="nav pull-right">
				<br><br> 
					<a class="btn btn-primary" href="/project1/index.php/orderCloud">서버 생성하기</a> 
			</div> 
			</div>
		</div>
	</div>

<script>
$(
		function(){
			$(":button").click(
				
				function(){
				    name = $(this)[0].id;
				    formindex = name.replace(/[^0-9]/g,"");
					action = name.substring(1);
					var formData = $("#form"+formindex).serialize();
					alert(formData);
					$('#result').html('통신중...');
					if(action=='start'){
						$.ajax({
								type : "POST",
								url: 'http://localhost/project1/index.php/cloudlist/startVM',
								data : formData,
								success : function(){
									alert(action+'실행성공');
									$('#state'+formindex).html('Running');
								},
								error : function( ){  
									alert(action+'실행실패');
									$('#result').html('통신실패');
								}
						}); 
					}else if(action == 'stop'){
						$.ajax({
								type : "POST",
								url: 'http://localhost/project1/index.php/cloudlist/stopVM',
								data : formData,
								success : function(){ 
									alert(action+'실행성공');
									$('#state'+formindex).html('Stopped');
								},
								error : function( ){ 
									alert(action+'실행실패');
									$('#result').html('통신실패');
								}
						}); 
					}else if(actino == 'reboot'){
						
				}  
		});
			  
}); 

 
</script>
<div id='result'></div>
<!-- 서버목록 -->
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12"> 
				<h5>서버목록 (총 <?= $vmcount?>건)</h5>
				<table class="table table-hover" >
					<thead>
						<tr>
							<td>번호</td>
							<td>계정명(displayname)</td>
							<td>운영체제(templatedisplaytext)</td>
							<td>데이터센터(zonename)</td>
							<td>생성시간(created)</td>
							<td>상태(state)</td>
							<td>제어</td>
						</tr>
					</thead>
					<tbody>
		<?php
	 
		for($i = 0; $i < $vmcount; $i ++) {
			if ($vmcount == 1) {
				$vm = $clouds['virtualmachine'];
			} else {
				$vm = $clouds['virtualmachine'][$i];
			}
			 
			echo "<tr><form id='form".$i."' method='post'><td>";
			echo "<input type='hidden' name='vmid' value='" . $vm ['id'] . "'/>";
			echo $i + 1;
			echo "</td><td>";
			echo $vm ['displayname'];
			echo "</td> <td>";
			echo $vm ['templatedisplaytext'];
			echo "</td> <td>";
			echo $vm ['zonename'];
			echo "</td> <td>";
			echo $vm ['created'];
			echo "</td> <td id='state".$i."'>";
			echo $vm ['state'];
			echo "</td> <td>";
			echo "<input class = 'btn' id='".$i."start' type='button' value='시작'/>";
			echo "<input class = 'btn' id='".$i."stop'  type='button' value='정지'/>";
			echo "<input class = 'btn' id='".$i."reboot' type='button' value='재부팅'/>";
			echo "</td></form></tr>";
		}
		?>
		</tbody>
				</table>
			</div>
		</div>
</div>

<!-- 서버관리메뉴 와 서브정보 -->
<div class="container-fluid">
	 <div class="row-fluid"> 