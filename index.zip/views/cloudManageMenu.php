 
 <div class="span2"> 
	 <ul class="nav nav-list">
		  <li class="nav-header">서버관리</li>
		  <li class="active"><a href="#">서버정보</a></li>
		  <li><a href="#">포트포워딩</a></li>	 
	</ul> 
 </div>
