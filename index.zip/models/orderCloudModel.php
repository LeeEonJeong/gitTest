<?php
// db에서 사용자의 클라우드 가져오기
/*
 * 해당 유저의 서버 정보 가져오기
 * 서칭기능
 * 볼륨이 붙여진 클라우드 가져오기
 *
 */
class OrderCloudModel extends CI_Model {
	function __construct() {
		parent::__construct ();
		$this->load->model ( 'callApiModel' ); 
	}
	
	function getlistAvailableProductTypes() { 
		 
		$zoneid='eceb5d65-6571-4696-875f-5a17949f3317';
		$cmdArr = array (
				"command" => "listAvailableProductTypes",
				"zoneid" => $zoneid,
				//"zoneid" => $_POST['zoneid'],
				"apikey" => $_SESSION ['apikey']
		);
		
		$listAvailableProductTypes = $this->callApiModel->callCommand( CallApiModel::URI, $cmdArr, $this->session->userdata ( 'secretkey' ) );
		 
		return $listAvailableProductTypes;
	}

	function getPackages(){
		$availableProductTypes = $this->getlistAvailableProductTypes();
		$count = $availableProductTypes['count'];
		$productTypes = $availableProductTypes['producttypes'];
		$packages = array();
		$index=0;
		
		if($count==0){
			return $packages;
		}
		
		$old='';
		for($i=0; $i<$count; $i++){
			$new = $productTypes[$i]['product'];
			if($new != $old && $new !=null){
				$packages[$index++] = $new;
				$old = $new;
			}
		}
		return $packages;			
	}
	
	function getProductsByPackage($package){
		$packageNum = $this->getPackageNum($package);
	 
		switch($packageNum){
			case 1: 
				return $this->getProducts('productid','std');
			case 2:
				return $this->getProducts('productid', 'high');
			case 3:
				return $this->getProducts('productid', 'ssd');
		}
	}
	
	function getPackageNum($package){
		if($package == 'Standard'){
			return 1;
		}else if($package == 'HighMemory'){
			return 2;
		}else if($package == 'SSD'){
			return 3;
		}
	}
	
	private function getProducts($condition, $substring){
		$availableProductTypes = $this->getlistAvailableProductTypes();
		$count = $availableProductTypes['count'];
		echo $count;
		$productTypes = $availableProductTypes['producttypes'];
		$products = array();
		$index=0;
		
		for($i=0; $i<$count; $i++){
			$product = $productTypes[$i];
			//echo var_dump($product)."<br>";
			
			if(strpos($product[$condition],$substring)){
				$products[$index++] = $product;
			}
		}
		return $products;
	}
	
	function getAvailableProductTypes($condition, $value){
		$availableProductTypes = $this->getlistAvailableProductTypes();
		$count = $availableProductTypes['count'];
		$productTypes = $availableProductTypes['producttypes'];
		$products = array();
		$index=0;
		
		for($i=0; $i<$count; $i++){
			$product = $productTypes[$i];
			if($product[$condition] == $value){
				$products[$index++] = $product; 
			}
		} 
		return $products;
	}
	 
	  
}