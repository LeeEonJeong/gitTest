<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	class Networklist extends MY_Controller{
		function __construct()
		{
			parent::__construct();
			$this->load->model('networksModel');
		}
		
		function index(){
			parent::setSessionWhere('network');
			$this->_head();
			$returnURI = '/networklist'; // 일단임의로 나중에 returnURI 다시 처리하자
			$this->_require_login($returnURI);
			
			$publicIps = $this->networksModel->getlistPublicIpAddresses();
		  
			$publicIpCount = $publicIps['count'];
			 
			$networklistdata = array(
					'publicIps' => $publicIps,
					'publicIpCount' => $publicIpCount
			); 
		
			$this->load->view('networklist', $networklistdata); 
		 	$this->load->view('networkManageMenu');
		    $this->load->view('networkInfo');
			$this->_footer();
		} 
		
		function getPublicIpInfo(){
			parent::setSessionWhere('network');
			$publicip = $this->networksModel->getPublicIpInfo();
			print(json_encode($publicip));
		}
		
		function getFireWallInfoByIpAddress(){
			parent::setSessionWhere('network');
			$portforwardingRules = $this->networksModel->getFireWallInfoByIpAddress();
			print(json_encode($portforwardingRules));
		}
		
		 
	}